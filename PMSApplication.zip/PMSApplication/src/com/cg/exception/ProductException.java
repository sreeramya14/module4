package com.cg.exception;

public class ProductException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6884671833258045477L;

	public ProductException()
	{
		super();
	}
	
	public ProductException(String message)
	{
		super(message);
	}

}
