package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Product;
import com.cg.exception.ProductException;


@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean deleteProduct(int id) throws ProductException {
		boolean isDeleted=false;
		try {
			Product bean=entityManager.find(Product.class, id);
			entityManager.remove(bean);
			isDeleted=true;
		} catch (Exception e) {
			throw new ProductException("unable to delete the records"+e.getMessage());
		}
		
		return isDeleted;
	}

	@Override
	public List<Product> viewAllProducts() throws ProductException {
  TypedQuery<Product> query=entityManager.createQuery("from Product", Product.class);
		
		List<Product> list = query.getResultList();
		return  list;
	}

}
