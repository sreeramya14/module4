package com.cg.dao;

import java.util.List;

import com.cg.bean.Product;
import com.cg.exception.ProductException;


public interface IProductDao {
	
	public boolean deleteProduct(int id)throws ProductException;
	
	/*public boolean deleteEmployee(int Id) throws EmployeeException;*/
	
	public List<Product> viewAllProducts()throws ProductException;
	/*public List<EmployeeBean> viewAllEmployees() throws EmployeeException;*/

}
