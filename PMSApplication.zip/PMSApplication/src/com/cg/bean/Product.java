package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
	
	
	@Id
	@Column(name="product_id")
	private int productid;
	@Column(name="product_name",length=15)
	private String productname;
	@Column(name="product_price",length=15)
	private int productprice;
	@Column(name="product_quantity",length=15)
	private int productquantity;
	@Column(name="description",length=30)
	private String description;
	
	
	
	
	public Product() {
		super();
	}




	public Product(int productid, String productname, int productprice,
			int productquantity, String description) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
		this.productquantity = productquantity;
		this.description = description;
	}


	public int getProductid() {
		return productid;
	}




	public void setProductid(int productid) {
		this.productid = productid;
	}




	public String getProductname() {
		return productname;
	}




	public void setProductname(String productname) {
		this.productname = productname;
	}




	public int getProductprice() {
		return productprice;
	}




	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}




	public int getProductquantity() {
		return productquantity;
	}




	public void setProductquantity(int productquantity) {
		this.productquantity = productquantity;
	}




	public String getDescription() {
		return description;
	}




	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
