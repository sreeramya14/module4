package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Product;
import com.cg.dao.IProductDao;
import com.cg.exception.ProductException;


@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private IProductDao productDao;

	@Override
	public boolean deleteProduct(int id) throws ProductException {
		return productDao.deleteProduct(id);
	}

	@Override
	public List<Product> viewAllProducts() throws ProductException {
		return productDao.viewAllProducts();
	}

}
