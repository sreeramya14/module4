package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.service.IProductService;

@Controller
public class ProductController {

	
	@Autowired
	private IProductService productService;
	
	
/*
	@RequestMapping("showHomePage")
	public String showHomePage()
	{
		return("index");
	}*/
	
	@RequestMapping("/showAll")
	public ModelAndView viewAllProducts(){
		
		ModelAndView mv=new ModelAndView();
		try {
			List<Product> list=productService.viewAllProducts();
			mv.setViewName("index");
			mv.addObject("list", list);
		} catch (ProductException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		return(mv);
	}
	
	
	
	
	@RequestMapping("/deleteProduct")
	public ModelAndView deleteProduct(@RequestParam("id") int Id)
	{
		
		ModelAndView mv=new ModelAndView();
		
			try {
				boolean isDeleted=productService.deleteProduct(Id);
				if(isDeleted)
				{
					
				List<Product> list=productService.viewAllProducts();
				mv.setViewName("index");
				mv.addObject("list", list);
				
				}
			} catch (ProductException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
			
		
		
		return (mv);
	}
}
